# Frameboard Studio 1.0.1 — validation

The 1.0 core release passed 24 browser workflow checks on 5 October 2026.
The 1.0.1 demo refresh passed nine additional focused checks on the same date.
Test host: Chromium Headless Shell 154.0.8037.92 on Linux, using actual
H.264 video decoding, pointer input, file uploads, downloads and canvas output.

## Demo refresh checks (1.0.1)

- Six distinct subjects, six distinct captured images and three A/B pairs
- Both H.264 sample clips decode at 1280 x 720 for 18 seconds
- All saved images and comparison images decode at their stated dimensions
- Review PDF and contact-sheet PNG export from the updated application
- Playback, seeking and fresh capture work with the replacement clips
- Fresh A/B capture matches the replacement clip timing
- Saved demo project reopens and relinks with source identity preserved
- Demo restores; layouts fit 1440, 1024, 768 and 390 pixel widths
- No uncaught browser errors or HTTP/HTTPS requests

All seven report pages and all three guide pages were rendered and visually
inspected. The fashion comparison crop was refined during this inspection.
The two sample clips are assembled from six AI-generated stills, with gentle
zooms and alternate crops. They are visual studies rather than live-action
footage. Sample statuses and notes are illustrative.

## Previously verified core workflows (1.0)

- Offline single-file demo loads two playable clips and six frames
- Review PDF downloads from the actual application
- Storyboard PDF and contact-sheet PNG download
- Playback advances and pauses
- Timestamp seeking and manual capture use video pixels
- Notes, priority and status persist in the project state
- Arrow, box and undo controls edit real annotation data
- Annotated PNG export downloads at capture resolution
- Version comparison captures the revised clip at a matched timestamp
- Status filter controls exported CSV; text is spreadsheet-safe
- Saved project includes notes, annotation geometry and comparison images
- Project reopening restores the board without embedding full videos
- Relinking both clips preserves previously captured feedback
- Batch capture skips duplicate times and preserves existing notes
- Batch cancellation stops promptly and retains completed frames
- Invalid project data is rejected without losing the current board
- Long feedback flows into additional PDF pages
- Desktop and narrow layouts have no horizontal overflow
- Demo can be restored after a complete editing session
- No uncaught browser errors
- Same-named replacement clip identities
- Earlier-source capture guard
- Portrait capture and overlay geometry
- Portrait PNG/PDF export

The application made no HTTP or HTTPS requests during the browser test.
The example report was exported by the actual application. All seven pages
were rendered and visually inspected. Long-note continuation and portrait
reports were checked. The three-page guide was rendered and checked for
layout and text bounds. The final ZIP passed its integrity check.

## Compatibility scope

Desktop Chromium was tested directly. Chrome and Edge use Chromium and are
recommended for trying this release, but this test does not certify every OS,
browser build or video codec. Windows, macOS and Safari were not run here.
Browser seeking is approximate; step FPS is a seek interval rather than an
exact source-frame guarantee. Reports are image-based PDFs. CSV provides
editable text. Captures are limited to a 1440-pixel long edge and 60 per board.

## Local project behavior

Save project downloads a portable snapshot of captures and notes. Full source
videos stay outside that snapshot and must be relinked for further capture.
New uploads create independent source identities. Relinking a saved project
preserves its source identity when its filename and size match.

## Technical references

- https://developer.mozilla.org/en-US/docs/Web/API/HTMLMediaElement/currentTime
- https://developer.mozilla.org/en-US/docs/Web/API/HTMLCanvasElement/toBlob
- https://developer.mozilla.org/en-US/docs/Web/API/File_API/Using_files_from_web_applications
